package abscon.instance.intension.terminal;

import abscon.instance.intension.Evaluator;
import abscon.instance.intension.types.Arity0Type;

public abstract class TerminalEvaluator extends Evaluator implements Arity0Type {
}
