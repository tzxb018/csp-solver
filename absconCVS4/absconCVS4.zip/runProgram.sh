java -Xmx256m -jar csp.jar $@
