package abscon.instance.intension.arithmetic;

import abscon.instance.intension.Evaluator;
import abscon.instance.intension.types.IntegerType;

public abstract class ArithmeticEvaluator extends Evaluator implements IntegerType{
}
