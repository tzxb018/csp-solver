package abscon.instance.intension.logical;

import abscon.instance.intension.Evaluator;
import abscon.instance.intension.types.BooleanType;

public abstract class LogicalEvaluator extends Evaluator implements BooleanType{
}
