package abscon.instance.intension.arithmetic;

import abscon.instance.intension.types.Arity2Type;

public abstract class Arity2ArithmeticEvaluator extends ArithmeticEvaluator implements Arity2Type{
}
