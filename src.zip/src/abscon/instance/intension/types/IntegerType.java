package abscon.instance.intension.types;

public interface IntegerType {
}
