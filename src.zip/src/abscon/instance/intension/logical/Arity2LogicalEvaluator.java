package abscon.instance.intension.logical;

import abscon.instance.intension.types.Arity2Type;


public abstract class Arity2LogicalEvaluator extends LogicalEvaluator implements Arity2Type {
}
