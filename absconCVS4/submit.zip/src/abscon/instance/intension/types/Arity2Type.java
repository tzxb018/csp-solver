package abscon.instance.intension.types;

public interface Arity2Type {
}
