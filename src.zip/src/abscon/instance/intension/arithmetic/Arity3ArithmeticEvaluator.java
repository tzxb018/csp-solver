package abscon.instance.intension.arithmetic;

import abscon.instance.intension.types.Arity3Type;

public abstract class Arity3ArithmeticEvaluator extends ArithmeticEvaluator implements Arity3Type{
}
