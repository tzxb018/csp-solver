package abscon.instance.intension.types;

public interface SymmetricType {
}
